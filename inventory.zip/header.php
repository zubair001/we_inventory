<body>


 <div class="container">
        <h1>Inventory System </h1>

<nav id="main-nav" role="navigation">
  <!-- Sample menu definition -->
  <ul id="main-menu" class="sm sm-blue">
   
    <li><a href="inventory.php">Dashboard</a>
      <ul>
        
        <li><a href="detail_view.php">Detail View</a></li>
      </ul>
    </li>
    <li><a href="#">Manage</a>
      <ul>
        <li ><a href="#">Manufacture</a>
          <ul>
            <li><a href="add_manufacture.php">Add</a></li>
            <li><a href="admin_view_manufacture.php">View</a></li>
            
            
          </ul>
        </li>
        
        <li><a href="#">Project</a>
          <ul>
            <li><a href="add_project.php">Add</a></li>
            <li><a href="admin_view_project.php">View</a></li>
            
            
          </ul>
        </li>
                
        <li><a href="#">Product</a>
          <ul>
            <li><a href="add_product.php">Add</a></li>
            <li><a href="admin_view_product.php">View</a></li>
          </ul>
        </li>
        
        <li><a href="#">User</a>
          <ul>
            <li><a href="add_user.php">Add</a></li>
            <li><a href="admin_view_user.php">View</a></li>
            
          </ul>
        </li>
        
        
      </ul>
    </li>
    
    <li><a href="">Report</a>
      <ul>
        <li><a href="detail_log.php">Detail Log</a></li>
        <li><a href="logbydate.php">Date Log</a></li>
        <li><a href="projectlog.php">Project Log</a></li>
        <li><a href="manufacturelog.php">Manufacture log</a></li>
      </ul>
    </li>
    
    <li><a href="requisite.php">Requisition</a></li>
    <li><a href="admin-request-list.php">Request</a></li>
    
    
    <li><a href="index.php">Log Out</a></li>
            
          </ul>
       
</nav>
