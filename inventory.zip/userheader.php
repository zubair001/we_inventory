<body>


 <div class="container">
 <div class="row">
 <h1>Inventory System</h1>  
       
    <div class="username">
              <?php echo "Welcome " . $_SESSION["username"] . "<br>";  ?> </div>             
        </div>

<nav id="main-nav" role="navigation">
  <!-- Sample menu definition -->
  <ul id="main-menu" class="sm sm-blue">
   
    <li><a href="userhome.php">Dashboard</a>
           
        
    
    <li><a href="req-list.php">Request List</a></li>
    
    
    
    <li><a href="index.php">Log Out</a></li>
            
          </ul>
       
</nav>
